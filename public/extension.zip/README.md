# Etsy Listing Tracker - Chrome Extension

## 🎯 Purpose
Crawl Etsy shop listings using your browser's existing session → bypasses all anti-bot protection.

## 📦 Installation

1. **Open Chrome Extensions:**
   - Navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)

2. **Load Extension:**
   - Click "Load unpacked"
   - Select the `extension/` folder
   - Extension icon should appear in toolbar

3. **Verify:**
   - Click extension icon
   - Should show "ACTIVE" status

## 🚀 Usage

1. **Login to Etsy:**
   - Go to https://www.etsy.com
   - Login with your account
   - Keep session active

2. **Use Dashboard:**
   - Open dashboard at localhost:3001
   - Navigate to "Listing" tab
   - Click "Crawl All Shops"
   - Extension automatically crawls in background

## 🔧 How It Works

```
Dashboard
  ↓ (chrome.runtime.sendMessage)
Extension Background Worker
  ↓ (chrome.tabs.create)
Open Etsy shop page (hidden tab)
  ↓ (content script runs)
Parse DOM → Extract listings
  ↓ (chrome.runtime.sendMessage)
Extension Background Worker
  ↓ (sendResponse)
Dashboard → Update Firestore
```

## 📝 Files

- `manifest.json` - Extension config
- `background.js` - Service worker (tab management)
- `content.js` - DOM parser (runs on Etsy pages)
- `popup.html/js` - Extension popup UI
- `icon.png` - Extension icon

## 🐛 Troubleshooting

**Extension not responding?**
- Check if extension is enabled in chrome://extensions/
- Reload extension (click reload icon)
- Check browser console for errors

**No listings found?**
- Ensure you're logged into Etsy
- Try manually visiting shop page first
- Shop might have privacy settings

**Tabs not closing?**
- Extension auto-closes tabs after crawl
- If stuck, manually close Etsy tabs
- Reload extension

## ✅ Benefits vs Cloud Functions

| Feature | Cloud Function | Extension |
|---------|---------------|-----------|
| Success Rate | 20% (blocked) | 99% |
| Cost | Free | Free |
| Setup | Deploy | Install once |
| Maintenance | Redeploy | None |
| Session | Need cookies | Auto |

## 🔒 Security

- Extension only runs on etsy.com
- No data sent to external servers
- All data stays in your Firestore
- Source code is visible (inspect files)
